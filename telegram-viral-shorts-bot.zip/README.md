# Telegram Viral Shorts Bot (no DB)

Minimal scaffold to start quickly. Created on 2025-10-19T15:48:01.030945Z.

## Quick start

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env  # fill values
python app/main.py
```

## Structure
```
app/            # code
data/           # runtime data (not committed)
.env            # secrets (never commit)
```
