import os
from aiogram import F, Router
from aiogram.filters import CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import StatesGroup, State
from aiogram.types import Message, CallbackQuery
from .texts import TEXTS
from .keyboards import lang_keyboard, agree_keyboard, main_menu_kb, utils_kb, shorts_kb, aboutus_kb
from .utils import _load_users, _save_users, ensure_user, send_key_to_backend

DEV_WEBHOOK_URL = os.getenv("DEV_WEBHOOK_URL", "")
ABOUT_URL = os.getenv("ABOUT_URL", "https://example.com/about")
LOGIN_URL = os.getenv("LOGIN_URL", "https://example.com/login")
SUPPORT_URL = os.getenv("SUPPORT_URL", "https://t.me/your_support")
TON_ADDRESS = os.getenv("TON_ADDRESS", "UQ...")

# Inject env URLs into keyboards placeholders
# (simple replace in runtime; for a larger app use a template or settings module)
import types
from . import keyboards as kbmod
kbmod.main_menu_kb.__code__ = (lambda L: kbmod.InlineKeyboardMarkup(inline_keyboard=[
    [kbmod.InlineKeyboardButton(text=L["about"], url=ABOUT_URL)],
    [kbmod.InlineKeyboardButton(text=L["login"], url=LOGIN_URL)],
    [kbmod.InlineKeyboardButton(text=L["shorts"], callback_data="menu:shorts")],
    [kbmod.InlineKeyboardButton(text=L["utils"], callback_data="menu:utils")],
    [kbmod.InlineKeyboardButton(text=L["about_us"], callback_data="menu:aboutus")],
])).__code__
kbmod.utils_kb.__code__ = (lambda L: kbmod.InlineKeyboardMarkup(inline_keyboard=[
    [kbmod.InlineKeyboardButton(text=L["invite"], callback_data="utils:invite")],
    [kbmod.InlineKeyboardButton(text=L["pay_ton"], callback_data="utils:pay")],
    [kbmod.InlineKeyboardButton(text=L["support"], url=SUPPORT_URL)],
    [kbmod.InlineKeyboardButton(text=L["back"], callback_data="back:main")],
])).__code__

router = Router()

class AddKey(StatesGroup):
    waiting_key = State()

def L(users, uid, key):
    lang = ensure_user(users, uid).get("lang", "ru")
    return TEXTS.get(lang, TEXTS["ru"])[key]

@router.message(CommandStart())
async def cmd_start(message: Message):
    users = _load_users()
    ensure_user(users, message.from_user.id)
    await message.answer(TEXTS["ru"]["choose_lang"], reply_markup=lang_keyboard())

@router.callback_query(F.data.startswith("lang:"))
async def set_lang(cb: CallbackQuery):
    users = _load_users()
    lang = cb.data.split(":", 1)[1]
    ensure_user(users, cb.from_user.id)["lang"] = lang
    _save_users(users)
    await cb.message.edit_text(TEXTS[lang]["agree_text"], reply_markup=agree_keyboard(TEXTS[lang]["agree_btn"]))
    await cb.answer()

@router.callback_query(F.data == "agree")
async def agree(cb: CallbackQuery):
    users = _load_users()
    ensure_user(users, cb.from_user.id)["consent"] = True
    _save_users(users)
    Ld = TEXTS[ensure_user(users, cb.from_user.id)["lang"]]
    await cb.message.edit_text(f"<b>{Ld['main_title']}</b>\n{Ld['main_msg']}", reply_markup=kbmod.main_menu_kb(Ld))
    await cb.answer()

@router.callback_query(F.data == "back:main")
async def back_main(cb: CallbackQuery):
    users = _load_users()
    Ld = TEXTS[ensure_user(users, cb.from_user.id)["lang"]]
    await cb.message.edit_text(f"<b>{Ld['main_title']}</b>\n{Ld['main_msg']}", reply_markup=kbmod.main_menu_kb(Ld))
    await cb.answer()

@router.callback_query(F.data == "menu:utils")
async def menu_utils(cb: CallbackQuery):
    users = _load_users()
    Ld = TEXTS[ensure_user(users, cb.from_user.id)["lang"]]
    await cb.message.edit_text(Ld["utils"], reply_markup=kbmod.utils_kb(Ld))
    await cb.answer()

@router.callback_query(F.data == "utils:invite")
async def utils_invite(cb: CallbackQuery):
    users = _load_users()
    Ld = TEXTS[ensure_user(users, cb.from_user.id)["lang"]]
    link = Ld["invite_text"].format(bot=(await cb.bot.get_me()).username, uid=cb.from_user.id)
    await cb.message.edit_text(link, reply_markup=kbmod.utils_kb(Ld))
    await cb.answer()

@router.callback_query(F.data == "utils:pay")
async def utils_pay(cb: CallbackQuery):
    users = _load_users()
    Ld = TEXTS[ensure_user(users, cb.from_user.id)["lang"]]
    await cb.message.edit_text(Ld["pay_text"].format(addr=TON_ADDRESS), reply_markup=kbmod.utils_kb(Ld))
    await cb.answer()

@router.callback_query(F.data == "menu:shorts")
async def menu_shorts(cb: CallbackQuery):
    users = _load_users()
    Ld = TEXTS[ensure_user(users, cb.from_user.id)["lang"]]
    await cb.message.edit_text(f"<b>{Ld['shorts']}</b>\n{Ld['shorts_text']}", reply_markup=shorts_kb(Ld))
    await cb.answer()

@router.callback_query(F.data == "menu:aboutus")
async def menu_aboutus(cb: CallbackQuery):
    users = _load_users()
    Ld = TEXTS[ensure_user(users, cb.from_user.id)["lang"]]
    await cb.message.edit_text(Ld["about_us"], reply_markup=aboutus_kb(Ld))
    await cb.answer()

@router.callback_query(F.data == "shorts:add")
async def shorts_add(cb: CallbackQuery, state: FSMContext):
    users = _load_users()
    Ld = TEXTS[ensure_user(users, cb.from_user.id)["lang"]]
    await state.set_state(AddKey.waiting_key)
    await cb.message.edit_text(Ld["enter_key"], reply_markup=aboutus_kb(Ld))
    await cb.answer()

@router.message(AddKey.waiting_key)
async def got_key(message: Message, state: FSMContext):
    users = _load_users()
    Ld = TEXTS[ensure_user(users, message.from_user.id)["lang"]]
    await message.answer(Ld["key_saved"]) 
    ok = await send_key_to_backend(DEV_WEBHOOK_URL, message.from_user.id, message.text.strip())
    await state.clear()
    if ok:
        await message.answer(Ld["key_ok"], reply_markup=shorts_kb(Ld))
    else:
        await message.answer(Ld["key_failed"], reply_markup=shorts_kb(Ld))

@router.callback_query(F.data == "shorts:list")
async def shorts_list(cb: CallbackQuery):
    users = _load_users()
    Ld = TEXTS[ensure_user(users, cb.from_user.id)["lang"]]
    await cb.message.edit_text(Ld["no_keys"], reply_markup=shorts_kb(Ld))
    await cb.answer()
